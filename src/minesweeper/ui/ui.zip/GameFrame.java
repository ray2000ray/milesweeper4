package minesweeper.ui;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SwingUtilities;


public class GameFrame extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 6935485228446313338L;
	private final int FRAME_WIDTH = 250;
    private final int FRAME_HEIGHT = 315;

    private final JLabel statusbar;
    
	private GameBoard board;
	
    private GameFrame panel;  
    
    private Container contentPane;  
  
    private JMenuItem startMI = new JMenuItem("Start");  
    
    private JMenuItem loadMI = new JMenuItem("Open");  
    
    public JMenuItem saveMI = new JMenuItem("Save");  
  
    private JMenu levelMenu = new JMenu("level");  
  
    private JMenuItem exitMI = new JMenuItem("Exit");  
  
    private JMenuItem aboutMI = new JMenuItem("About"); 
    
    private JRadioButtonMenuItem levelEasy = new JRadioButtonMenuItem("easy",  
            true);  //20%
  
    private JRadioButtonMenuItem levelNormal = new JRadioButtonMenuItem("normal", 
            false);  //40%
  
    private JRadioButtonMenuItem levelHard = new JRadioButtonMenuItem("hard",  
            false);  // 60%
  
    private JRadioButtonMenuItem levelNightmare = new JRadioButtonMenuItem("nightmare",  
            false);  // 80%
  
    public String level = "normal";  
    
    
    public GameFrame() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setLocationRelativeTo(null);
        setTitle("Minesweeper");

        //setTitle(Board.SNAKE_GAME);  

        setResizable(false);  
  
        JMenuBar menuBar = new JMenuBar();  
        setJMenuBar(menuBar);  
  
        JMenu setMenu = new JMenu("Set");  
        JMenu helpMenu = new JMenu("Help");  
  
        setMenu.setMnemonic('s');  
        setMenu.setMnemonic('H');  
  
        menuBar.add(setMenu);  
        menuBar.add(helpMenu);  
  
        setMenu.add(startMI);  
        setMenu.addSeparator(); 
  
        setMenu.addSeparator();  
        setMenu.add(levelMenu);  
        setMenu.addSeparator();  
        setMenu.add(exitMI);  
  
        setMenu.addSeparator();  
        setMenu.add(level);  
        setMenu.addSeparator();  
        setMenu.add(exitMI);  
  
        ButtonGroup group = new ButtonGroup();  
        group.add(levelEasy);  
        group.add(levelNormal);  
        group.add(levelHard);  
        group.add(levelNightmare);  
  
  
        levelMenu.add(levelEasy);  
        levelMenu.add(levelNormal);  
        levelMenu.add(levelHard);  
        levelMenu.add(levelNightmare);  
        
        
        statusbar = new JLabel("");
        add(statusbar, BorderLayout.SOUTH);

        add(new GameBoard(statusbar));

        setResizable(false);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            
            @Override
            public void run() {                
                JFrame ex = new GameFrame();
                ex.setVisible(true);                
            }
        });
    }
}